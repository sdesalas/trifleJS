﻿
// This is a simple example of how to set a variable
// Its used internally for testing script injection 
// phantom.injectJs();

var ___test190234 = [] instanceof Array;
