﻿
/*
*/


console.log("hello world");
phantom.exit();