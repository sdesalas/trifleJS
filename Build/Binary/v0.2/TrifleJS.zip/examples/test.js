﻿
/*
*/


var page = new WebPage();

page.evaluate(function() {
    return x;
}, 1)